package com.ncq.algo;

import java.util.Arrays;

/**
 * The Class AlgoOne.
 */
public class AlgoOne {

	/**
	 * Solution.
	 *
	 * @param n            the n
	 * @param a the a
	 * @return the int[]
	 */
	public int[] solution(int n, int[] a) {

		final int condition = n + 1;
		int currentMax = 0;
		int countersArray[] = new int[n];

		for (int i = 0; i < a.length; i++) {
			int currentValue = a[i];
			if (currentValue == condition) {
				Arrays.fill(countersArray, currentMax);
			} else {
				int position = currentValue - 1;
				int localValue = countersArray[position] + 1;
				countersArray[position] = localValue;

				if (localValue > currentMax) {
					currentMax = localValue;
				}
			}

		}

		return countersArray;
	}
}
