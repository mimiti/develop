package com.ncq.workflow.api.repository;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ncq.workflow.api.filter.SearchCriteria;
import com.ncq.workflow.api.filter.WorkflowSpecification;
import com.ncq.workflow.api.model.Workflow;


@RunWith(SpringRunner.class)
@SpringBootTest
public class WorkflowRepositorySpecificationTest {

    @Autowired
    private WorkflowRepository repository;
 
    private Workflow workflowFacture=null;
    private Workflow workflowCommerce=null;
    List<Workflow>workflowList=new ArrayList<>();
 
    @Before
    public void init() {
    	workflowFacture = new Workflow();
    	workflowFacture.setName("Facture");
    	workflowFacture.setEnabled(2);

    	workflowList.add(workflowFacture);
 
    	workflowCommerce = new Workflow();
    	workflowCommerce.setName("Commerce");
    	workflowCommerce.setEnabled(2);

    	workflowList.add(workflowCommerce);
    }
    
    @Test
    public void givenNameWhenGettingListOfWorkflowsThenCorrect() {
        WorkflowSpecification spec = 
          new WorkflowSpecification(new SearchCriteria("Name", ":", "Facture"));
         
        List<Workflow> results = repository.findAll(spec);
     
        assertThat(results.contains(workflowFacture),is(true));
        assertThat(results.contains(workflowFacture), is(false));
    }
}
