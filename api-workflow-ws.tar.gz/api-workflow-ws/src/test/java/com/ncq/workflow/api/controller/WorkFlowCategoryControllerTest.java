package com.ncq.workflow.api.controller;

import static org.hamcrest.CoreMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;

import com.ncq.workflow.api.filter.SearchCriteria;
import com.ncq.workflow.api.model.WorkflowCategory;
import com.ncq.workflow.api.repository.WorkflowCategoryRepository;


@RunWith(SpringRunner.class)
@WebMvcTest(WorkflowCategoryController.class)
public class WorkFlowCategoryControllerTest {
	@Autowired
	private MockMvc mvc;
	@Mock
	private WorkflowCategoryRepository workflowCategoryRepository;
	
	 @Mock
	 private WorkflowCategory category;

	@MockBean
	private RestTemplate restTemplate;
	@Test
	public void testGetAll_isOk() throws Exception {
		  when(workflowCategoryRepository.findAll()).thenReturn(new ArrayList<>());
		mvc.perform(get("/workflowCategories").contentType(APPLICATION_JSON)).andExpect(status().is2xxSuccessful());
	}
}
