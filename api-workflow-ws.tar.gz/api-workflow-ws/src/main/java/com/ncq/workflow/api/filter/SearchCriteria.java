package com.ncq.workflow.api.filter;

import javax.persistence.criteria.Expression;

import org.hibernate.query.criteria.internal.predicate.BooleanExpressionPredicate;

/**
 * The Class SearchCriteria.
 */
public class SearchCriteria {
	    
    	/** The key. */
    	private String key;
	    
    	/** The operation. */
    	private String operation;
	    
    	/** The value. */
    	private Object value;
		
		

		public SearchCriteria(String key, String operation, Object value) {
			super();
			this.key = key;
			this.operation = operation;
			this.value = value;
		}

		/**
		 * Gets the key.
		 *
		 * @return the key
		 */
		public String getKey() {
			return key;
		}
		
		/**
		 * Sets the key.
		 *
		 * @param key the new key
		 */
		public void setKey(String key) {
			this.key = key;
		}
		
		/**
		 * Gets the operation.
		 *
		 * @return the operation
		 */
		public String getOperation() {
			return operation;
		}
		
		/**
		 * Sets the operation.
		 *
		 * @param operation the new operation
		 */
		public void setOperation(String operation) {
			this.operation = operation;
		}
		
		/**
		 * Gets the value.
		 *
		 * @return the value
		 */
		public Object getValue() {
			return value;
		}
		
		/**
		 * Sets the value.
		 *
		 * @param value the new value
		 */
		public void setValue(Object value) {
			this.value = value;
		}

		public boolean isOrPredicate() {
			return false;
		}
	    
	    
	    

}
