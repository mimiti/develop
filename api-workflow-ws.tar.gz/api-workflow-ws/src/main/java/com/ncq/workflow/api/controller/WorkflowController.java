package com.ncq.workflow.api.controller;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ncq.workflow.api.filter.WorkflowSpecificationsBuilder;
import com.ncq.workflow.api.model.Workflow;
import com.ncq.workflow.api.repository.WorkflowRepository;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/")
public class WorkflowController {
	@Autowired
	private WorkflowRepository workflowRepository;
	@ApiOperation(value = "Getting workflows list")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved workflow list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@GetMapping("workflows")
	@ResponseBody
    public List<Workflow>search(@RequestParam(value = "search") String search) {
		 WorkflowSpecificationsBuilder builder = new WorkflowSpecificationsBuilder();
	        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)(\\w+?),");
	        Matcher matcher = pattern.matcher(search + ",");
	        while (matcher.find()) {
	            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
	        }
	         
	        Specification<Workflow> spec = builder.build();
	        return workflowRepository.findAll(spec);
	    }
    }

