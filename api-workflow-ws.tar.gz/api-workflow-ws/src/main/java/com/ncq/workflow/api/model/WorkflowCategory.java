package com.ncq.workflow.api.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The Class WorkflowCategory.
 */
@Entity
@Table(name = "WorkflowCategory")
public class WorkflowCategory {

	/** The id category. */
	private int idCategory;
	
	/** The description. */
	private String description;
	
	/** The name. */
	private String name;
	
	/** The logo. */
	private String logo;
	
	/** The enabled. */
	private int enabled;
	
	/** The workflows. */
	private List<Workflow> workflows;

	/**
	 * Instantiates a new workflow category.
	 */
	public WorkflowCategory() {
		super();
	}

	/**
	 * Instantiates a new workflow category.
	 *
	 * @param idCategory the id category
	 * @param description the description
	 * @param name the name
	 * @param logo the logo
	 * @param enabled the enabled
	 * @param parentCategory the parent category
	 */
	public WorkflowCategory(int idCategory, String description, String name, String logo, int enabled,
			ParentCategory parentCategory) {
		super();
		this.idCategory = idCategory;
		this.description = description;
		this.name = name;
		this.logo = logo;
		this.enabled = enabled;
		this.parentCategory = parentCategory;
	}

	/**
	 * Gets the id category.
	 *
	 * @return the id category
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getIdCategory() {
		return idCategory;
	}

	/**
	 * Sets the id category.
	 *
	 * @param idCategory the new id category
	 */
	public void setIdCategory(int idCategory) {
		this.idCategory = idCategory;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the logo.
	 *
	 * @return the logo
	 */
	public String getLogo() {
		return logo;
	}

	/**
	 * Sets the logo.
	 *
	 * @param logo the new logo
	 */
	public void setLogo(String logo) {
		this.logo = logo;
	}

	/**
	 * Gets the enabled.
	 *
	 * @return the enabled
	 */
	public int getEnabled() {
		return enabled;
	}

	/**
	 * Sets the enabled.
	 *
	 * @param enabled the new enabled
	 */
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	/**
	 * Gets the parent category.
	 *
	 * @return the parent category
	 */
	public ParentCategory getParentCategory() {
		return parentCategory;
	}

	/**
	 * Sets the parent category.
	 *
	 * @param parentCategory the new parent category
	 */
	public void setParentCategory(ParentCategory parentCategory) {
		this.parentCategory = parentCategory;
	}

	/**
	 * Gets the workflows.
	 *
	 * @return the workflows
	 */
	@OneToMany
	public List<Workflow> getWorkflows() {
		return workflows;
	}

	/**
	 * Sets the workflows.
	 *
	 * @param workflows the new workflows
	 */
	public void setWorkflows(List<Workflow> workflows) {
		this.workflows = workflows;
	}

	/** The parent category. */
	private ParentCategory parentCategory;

}
