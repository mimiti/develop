package com.ncq.workflow.api.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The Class Workflow.
 */
@Entity
@Table(name = "Workflow")
public class Workflow {
	
	/** The id workflow. */
	private int idWorkflow;
	
	/** The name. */
	private String name;
	
	/** The description. */
	private String description;
	
	/** The enabled. */
	private int enabled;
	
	/** The workflow categories. */
	private List<WorkflowCategory> workflowCategories;

	/**
	 * Instantiates a new workflow.
	 */
	public Workflow() {
		super();
	}

	/**
	 * Instantiates a new workflow.
	 *
	 * @param idWorkflow the id workflow
	 * @param name the name
	 * @param description the description
	 * @param enabled the enabled
	 */
	public Workflow(int idWorkflow, String name, String description, int enabled) {
		super();
		this.idWorkflow = idWorkflow;
		this.name = name;
		this.description = description;
		this.enabled = enabled;
	}
	
	/**
	 * Gets the id workflow.
	 *
	 * @return the id workflow
	 */
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	public int getIdWorkflow() {
		return idWorkflow;
	}

	/**
	 * Sets the id workflow.
	 *
	 * @param idWorkflow the new id workflow
	 */
	public void setIdWorkflow(int idWorkflow) {
		this.idWorkflow = idWorkflow;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the description.
	 *
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 *
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	 
 	/**
 	 * Gets the enabled.
 	 *
 	 * @return the enabled
 	 */
 	@Column(name = "status", nullable = false)
	public int getEnabled() {
		return enabled;
	}

	/**
	 * Sets the enabled.
	 *
	 * @param enabled the new enabled
	 */
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	 
 	/**
 	 * Gets the workflow categories.
 	 *
 	 * @return the workflow categories
 	 */
 	@OneToMany
	public List<WorkflowCategory> getWorkflowCategories() {
		return workflowCategories;
	}

	/**
	 * Sets the workflow categories.
	 *
	 * @param workflowCategories the new workflow categories
	 */
	public void setWorkflowCategories(List<WorkflowCategory> workflowCategories) {
		this.workflowCategories = workflowCategories;
	}

	

}
