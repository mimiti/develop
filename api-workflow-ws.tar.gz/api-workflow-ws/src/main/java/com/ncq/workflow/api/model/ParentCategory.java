package com.ncq.workflow.api.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class ParentCategory.
 */
@Entity
@Table(name = "ParentCategory")
public class ParentCategory {
	
	/** The id parent. */
	private int idParent;
	
	/**
	 * Instantiates a new parent category.
	 */
	public ParentCategory() {
		super();
	}

	/**
	 * Instantiates a new parent category.
	 *
	 * @param idParent the id parent
	 */
	public ParentCategory(int idParent) {
		super();
		this.idParent = idParent;
	}
	
	/**
	 * Gets the id parent.
	 *
	 * @return the id parent
	 */
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	public int getIdParent() {
		return idParent;
	}

	/**
	 * Sets the id parent.
	 *
	 * @param idParent the new id parent
	 */
	public void setIdParent(int idParent) {
		this.idParent = idParent;
	}

}
