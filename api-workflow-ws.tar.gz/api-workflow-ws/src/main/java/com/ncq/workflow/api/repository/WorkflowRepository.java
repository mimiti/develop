package com.ncq.workflow.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.ncq.workflow.api.model.Workflow;

/**
 * The Interface WorkflowRepository.
 *
 * @param Workflow
 */
@Repository
public interface WorkflowRepository extends JpaRepository<Workflow,Integer>,JpaSpecificationExecutor<Workflow>{

}
