package com.ncq.workflow.api.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.jpa.domain.Specification;

import com.ncq.workflow.api.model.Workflow;

/**
 * The Class WorkflowSpecificationsBuilder.
 */
public class WorkflowSpecificationsBuilder {
	
	/** The params. */
	private final List<SearchCriteria> params;
	 
    /**
     * Instantiates a new workflow specifications builder.
     */
    public WorkflowSpecificationsBuilder() {
        params = new ArrayList<>();
    }
 
    /**
     * With.
     *
     * @param key the key
     * @param operation the operation
     * @param value the value
     * @return the workflow specifications builder
     */
    public WorkflowSpecificationsBuilder with(String key, String operation, Object value) {
        params.add(new SearchCriteria(key, operation, value));
        return this;
    }
 
    /**
     * Builds the.
     *
     * @return the specification
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public Specification<Workflow> build() {
        if (params.isEmpty()) {
            return null;
        }
 
        List<Specification> specs = params.stream()
          .map(WorkflowSpecification::new)
          .collect(Collectors.toList());
         
        Specification<Workflow> result = specs.get(0);
 
        for (int i = 1; i < params.size(); i++) {
            result = ( params.get(i))
              .isOrPredicate()
                ? Specification.where(result)
                  .or(specs.get(i))
                : Specification.where(result)
                  .and(specs.get(i));
        }       
        return result;
    }

}
