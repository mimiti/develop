package com.ncq.workflow.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 * The Class WorkFlowApiApplication.
 */
@SpringBootApplication
public class WorkFlowApiApplication {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(WorkFlowApiApplication.class, args);
	}

}
