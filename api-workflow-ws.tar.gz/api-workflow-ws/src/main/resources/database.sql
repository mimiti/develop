CREATE TABLE `WorkflowCategory` (
	`idCategory` INT NOT NULL AUTO_INCREMENT,
	`Description` VARCHAR(255),
	`Name` VARCHAR(255) NOT NULL,
	`Logo` VARCHAR(255) NOT NULL,
	`CreateAt` DATETIME NOT NULL,
	`UpdateAt` DATETIME NOT NULL,
	`Enabled` INT NOT NULL,
	`ParentCategory` INT NOT NULL,
	PRIMARY KEY (`idCategory`)
);

CREATE TABLE `ParentCategory` (
	`idParent` INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY (`idParent`)
);

CREATE TABLE `Workflow` (
	`idWorkflow` INT NOT NULL AUTO_INCREMENT,
	`Name` VARCHAR(255) NOT NULL AUTO_INCREMENT,
	`Description` VARCHAR(255) NOT NULL AUTO_INCREMENT,
	`Enabled` INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY (`idWorkflow`)
);

ALTER TABLE `WorkflowCategory` ADD CONSTRAINT `WorkflowCategory_fk0` FOREIGN KEY (`ParentCategory`) REFERENCES `ParentCategory`(`idParent`);
